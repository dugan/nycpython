Release Notes
=============

Release notes from various versions of South.

.. toctree::
   :maxdepth: 1
   
   0.7